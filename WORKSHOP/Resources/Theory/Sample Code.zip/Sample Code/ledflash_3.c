// Sample program to make LED flash.
// LED is active low on PD0.
// Instead of testing pin and changing its state we can just toggle it!

// Note how we have defined mask here. PD0 is defined in iom64.h through our included avr/io.h
// this structure may make programmers intent more clear and mask less prone to error.

#include <avr/io.h>

#define		LED_MASK		(1<<PD0)
#define		TOGGLE_LED		PORTD ^= LED_MASK

int main(void)
{
	unsigned int count=0; 

	DDRD=0xFF; //Set PORTD all output

	while(1)//loop forever
	{
		// crude delay
		while (count < 6550) count++; 
		count=0; 
				
		TOGGLE_LED; 
	}
}		
