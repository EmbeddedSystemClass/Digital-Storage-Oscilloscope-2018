/* 431-481 sample program, graeme pendock 2/07
/  Flashes an LED wired to D0
/  Delay provide by a software counter.
/  This program is not a model of good programming ! (it will be improved upon during tute) */


//this file associates port nmemonics eg PORTD with actual register addresses
#include <avr/io.h>			

int main(void)
{
	unsigned int i; 
	
	//note: prefix 0x denotes number is in hex
	
	DDRD = 0xFF; 		//initalise all port D pins to be output
	PORTD = 0xFF;		//set them to logic '1' (LED off, since its wired active low)

	while(1)			//loop forever; embedded application will typically execute task continuosly
	{
		//generate a delay using a loop that simply counts but runs no task
		// (note compiling with optimisation set eg -Os will remove this because it does nothing useful !)
		for (i = 0; i < 10000; i++) {} 
		
		//toggle LED
		if (PORTD == 0xFF)   
		{
			PORTD = 0xFE;		//if LED is off, then turn it on
		}
		else
		{
			PORTD = 0xFF; 		//else turn it on
		}
		
	}
	
}
