// LED supposedly toggles when button is pushed
// may very often not since non swicth debouncing !

#include <avr/io.h>

#define		FALSE		0
#define		TRUE		1

#define		LED_MASK			(1<<PD0)
#define		TOGGLE_LED			PORTD ^= LED_MASK
#define		BUTTON_IS_PUSHED	(PINC & (1<<PINC0))		//TRUE, ie non-zero, if button pushed

//-----------------------------------------------------------------------------
int main(void)
{
	unsigned char button_read = FALSE;	// flag to note if we have read button and toggled LED
	
	DDRD = 0xFF; 				//Set PORTD all output
	DDRC = ~(1<<DDC0);			//PINC0 input, rest port C output			
	
	while(1) 
	{
		if(BUTTON_IS_PUSHED && (button_read == FALSE))
		{
			TOGGLE_LED;
			button_read = TRUE;
		}	
		
		if(!BUTTON_IS_PUSHED) button_read = FALSE;	// wait until button released then clear flag
	};			
}		
