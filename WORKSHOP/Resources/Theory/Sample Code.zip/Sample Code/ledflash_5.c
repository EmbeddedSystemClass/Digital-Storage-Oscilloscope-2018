// Sample program to make LED flash using timer and interrupt !
// The advantage of using interrupts is that we don't have to tie the program
// up continuosly polling the overflow flag.
// We could run other code in the main loop (its empty here !) and the LED
// just flashes away in the background.

#include <avr/io.h>
#include <avr/interrupt.h>

#define		LED_MASK		(1<<PD0)
#define		TOGGLE_LED		PORTD ^= LED_MASK
#define 	TMR0START 		0xC0

void setupTimer0(void);

//--------------------------------------------------------------
// interrupt routine to service overflow on counter 0
// flag TOV0 cleared in ISR
// see avr_libc reference manual \winavr\doc\avr-libc
ISR(TIMER0_OVF_vect)
{
	TCNT0 = TMR0START;		//restart counter

	TOGGLE_LED;
} 
//--------------------------------------------------------------------------
void setupTimer0(void)
{
	TCCR0B = 0x05;			// set prescale to divide by 1024, 
	TCNT0 = TMR0START;		// set counter0 to initial value
	TIMSK0 |= (1<<TOIE0); 	//enable timer0 overflow interrupt. see section 13.8.6
}
//-----------------------------------------------------------------------------
int main(void)
{
	DDRD=0xFF; 				//Set PORTD all output
	setupTimer0();
	sei();					//enable interupts
	
	while(1) 
	{
	
		// currently nothing happens here; but this loop would service other tasks in your app.
	
	};			// main program loop
}		
