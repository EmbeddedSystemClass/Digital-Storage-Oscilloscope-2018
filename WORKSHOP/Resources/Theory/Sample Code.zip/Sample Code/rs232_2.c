// RS232 demo for atmega48

#include <avr/io.h>
#include <stdio.h>

void uart_putch(unsigned char byte);
//unsigned char uart_getch(void);


//-------------------------------------------------------
void uart_init(void)
// 20 MHz system clock
// set up UART for 9600 baud, U2x=0, UBRR=129 for 20 MHz, frame 8N1
{
	UBRR0H = 0;
	UBRR0L = 129;
	UCSR0B = (1<< RXEN0) | (1<<TXEN0);  // enable transmitter and receiver
} 
//-------------------------------------------------------
void uart_putch(unsigned char byte) 	// output one byte 
{
	while(!(UCSR0A & (1<<UDRE0)));	  // wait until flag set 

	UDR0 = byte;
}  
//-------------------------------------------------------
int main(void)
{

	uart_init();

	
	fdevopen((void*)uart_putch, 0);       // associate uart_putch output function with stdio
	puts("hello world!\r");
	
	while(1);
}
