// Sample program to demo PWM
// Connect LEDs on D5 (OCOB) and D6 (OCOA) - they will blink at same frequency with different duty cycles
// We will use timer0 since its the simplest.
// Many PWM "modes" are offered. We will use Fast Mode - its relatively easy to understand.
// Study registers in section 13.8

#include <avr/io.h>

//-----------------------------------------------------------------------------
int main(void)
{
// First we configure register TCCR0A
// - for PWM Fast mode. WGM02:0 = 3. Counter0 counts from 0x00 to 0xFF, overflows etc
// - we set noninverting mode for channels A and B. The outputs (OC0x) are set when 
//   the counter reaches 0x00 and cleared when they match corresponding compare register 
//   hence CMOA1:0 =2 and similarly for CM0B1:0 = 2.
// 	 Hence full value for register is 1010xx11 = 0xA3
	TCCR0A = 0xA3;	
	
// Next we set register TCCR0B
// - for PWM the FOCOx bits are 0
// - for fast WGM02 is 0
// - we will set prescale to 1024 CS2:0=5; this is slow enough so we can see LEDs blink
	TCCR0B = 0x05;			
	
// The PWM outputs are OC0A and OC0B which are available on pins PD6&5.
// hence we must set these pins as outputs. We will set all PORTD output.
	DDRD = 0xFF; 			

// the PWM duty cycle is set in the compare registers, min=0, max=ff
	OCR0A = 0x80;	//0x80 = 50% 
	OCR0B = 0x80;	//##
 	
	while(1) {};	// program runs doing nothing, leaving PWM running in background	
					// can modify PWM duty cycles on the fly....
}		
