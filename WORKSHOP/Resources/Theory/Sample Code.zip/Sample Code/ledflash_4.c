// Sample program to make LED flash using timer .
// Previous program used software loop to do timing.
// Here we show a better solution using the hardware timer/counter inside the micro.
// We will use the 8-bit timer0

#include <avr/io.h>


#define		LED_MASK		(1<<PD0)
#define		TOGGLE_LED		PORTD ^= LED_MASK

// the following is the value we will load into the counter.  The larger this value the sooner
// the counter will rollover (and faster the LED will flash)
#define 	TMR0START 		0xC0  

//-----------------------------------------------------------------------------
int main(void)
{

	DDRD=0xFF;				 //Set PORTD all output
	
// this sets the value of the prescaler, ie how much the system clock (1 MHz) is divided by before
// it clocks the counter.  We will prescale by 1024. See section 13.8.1 and table 13-9.
// Hence clock frequecny to timer = 1MHz/1024 = 976 Hz
	TCCR0B = 0x05;			// prescale by 1024, 
	
// load the value into counter. Counter now increments this every clock cycle he gets from prescaler
	TCNT0 = TMR0START;		

	
	while(1)
	{
	// we now continuosly poll the Timer 0 overflow bit TOV0 in the timers Interupt Flag Register TIFR0
	// and just loop while it is low.  See section 13.8.7. When the counter rolls over this bit is set and we proceed.
		do {
		
		// currently nothing happens here; but this loop would service other tasks in your app.
		
		} while(!(TIFR0 & (1<<TOV0))); // wait until timer overflow
		
		// we reprogram the counter to our desired start count again
		TCNT0 = TMR0START;					//restart timer0 counter

		// and clear the overflow bit so we can wait for it again
		// note: to clear the overflow flag we write 1 to it
		TIFR0 &= (1<<TOV0);					// clear timer overflow

		TOGGLE_LED; 

	}
}		
