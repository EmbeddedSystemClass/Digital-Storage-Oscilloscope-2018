//Sample program to make LED flash.
//LED is active low on PD0.
// Demonstrates the use of mask to change only pin to LED
// whilst leaving the other pins unchanged.

#include <avr/io.h>

#define		LED_MASK		(1<<PD0)
#define		TURN_LED_OFF	PORTD |= LED_MASK
#define		TURN_LED_ON		PORTD &= ~LED_MASK
#define		LED_IS_OFF		PIND & LED_MASK			//TRUE, ie non-zero, if LED off

int main(void)
{
	unsigned int i; 

	DDRD=0xFF; //Set PORTD's data direction register as output

	while(1)//loop forever
	{
		//generate a delay using a loop that simply counts but runs no task
		// (note compiling with optimisation set eg -Os will remove this because it does nothing useful !)
		for (i = 0; i < 2000; i++) {} 
		
		//code is now more readable, as well as being more scalable, robust, etc
		if (LED_IS_OFF) TURN_LED_ON; 
		else TURN_LED_OFF;
	}
}		// end main
